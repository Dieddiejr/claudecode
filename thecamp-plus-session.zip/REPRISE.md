# Reprise — TheCamp+ / Radio thecamp (Récitales)

Session d'origine : https://claude.ai/code/session_01Ui54rzqVfh8yBUpJLtPKU9
Dépôt : Dieddiejr/claudecode — branche `claude/vibrant-lamport-0dego8` — PR https://github.com/Dieddiejr/claudecode/pull/1

## Contenu du zip
- `thecamp-plus/index.html` : page démo TheCamp+ (HTML/CSS/JS autonome, une seule page)
- `Radio_thecamp.html` : première proposition « Radio thecamp » (charte Les Rencontres d'Agir), à mettre de côté
- `Les_Rencontres_d_Agir.html` : template de charte d'origine
- `REPRISE.md` : ce fichier

## Contexte (Notion d'Abdou, lu le 05/10/2026)
- thecamp : campus d'innovation à Aix-La Duranne (550 rue Denis Papin), repris en 2022 par Kevin Polizzi (Unitel), président Stéphane Soto, DG Francis Papazian. Plan de redressement validé le 11/07/2025, passif > 28 M€ : pas de production lourde sans acompte.
- Trou de communication : rien de ce qui se dit sur le campus ne survit à la journée (conférences, LEX, Speed Meeting Business mensuel, Training Hub). Idée : radio en ligne qui éditorialise et archive.
- Séquence décidée le 17/09 : porte d'entrée via Polizzi (pose de première pierre Théodora le 09/10 à 11h), prise de parole dans Le Sud Autrement avec Soto, radio ensuite. Abdou a demandé le 05/10 de commencer par la radio : arbitrage à confirmer.
- Ne jamais entrer par « votre communication n'est pas bonne ». Prix (catalogue) à ne montrer qu'à la restitution : partenaire média 2 500–6 000 €, épisode 1 500–2 500 €, saison ~2 000 €, portrait ~450 €. Max 2 pilotes gratuits (déjà utilisés : La Bétheline, FCE).

## Demande en cours
Page « TheCamp+ » à publier sur studiorecitales.fr (idée : sous-domaine projet.studiorecitales.fr) pour l'envoyer en démonstration à thecamp. Structure copiée d'une image de référence (site Mind-Ed) :
1. Haut de page : grand logo « TheCamp+ » avec 4 vignettes, texte d'accroche.
2. Section verte « Récents » (à la place de « Events ») : 6 cartes (3 visibles + 3 en plus), flèches.
3. Très grand cadre vidéo 16/9 juste après : y mettre l'entretien avec Tchalé (vidéo déjà sur le WordPress de Récitales).
4. « À écouter » : podcasts. 5. Carte « À propos ».

## Reste à faire
1. Renseigner `VIDEO_SRC` (fin de `thecamp-plus/index.html`) avec l'URL .mp4 ou d'embed de la vidéo Tchalé.
2. Insérer les photos (cartes `.shot`, vignettes `.t1`–`.t4`, pochettes `.cover`) : remplacer les classes `ph gX` par `style="background-image:url(...)"`.
3. Remplacer les textes d'exemple des 6 cartes et des épisodes ; `data-audio="URL.mp3"` active le lecteur.
4. Reprendre couleurs et police de studiorecitales.fr (variables `:root`, actuellement celles de la référence).
5. Publier sur projet.studiorecitales.fr (ou page WordPress), vérifier mobile.

## Pourquoi la session cloud n'a pas pu publier
Réseau cloud bloquant studiorecitales.fr et thecamp.fr, aucun connecteur WordPress branché, aucun identifiant fourni. Une session locale (ou la session habituelle d'Abdou) avec ses accès WordPress peut le faire.

## Prompt à coller dans la nouvelle session
> Lis `REPRISE.md` et `thecamp-plus/index.html`. Récupère sur mon WordPress la vidéo de l'entretien avec Tchalé, mets-la dans le cadre vidéo, reprends la charte de studiorecitales.fr, puis publie la page sur projet.studiorecitales.fr. Ne publie rien d'autre sans me demander.
